import tkinter as tk
from tkinter import scrolledtext

class FakeRobloxInjector:
    def __init__(self, root):
        self.root = root
        self.root.title("CeleryFixed")
        self.root.geometry("600x400")
        self.root.configure(bg="#1c1c1c")  
        

        self.root.overrideredirect(True)
        

        self.drag_start_x = 0
        self.drag_start_y = 0
        

        self.title_bar = tk.Frame(root, bg="#2b2b2b", height=30)
        self.title_bar.pack(fill='x', side='top')
        
        # Title Label
        self.title_label = tk.Label(self.title_bar, text="CeleryFixed", font=("Arial", 18, "bold"), fg="#d8a4ff", bg="#2b2b2b")
        self.title_label.pack(side='left', padx=10)
        
        # Close Button
        self.close_button = tk.Button(self.title_bar, text="X", command=self.close_app, font=("Arial", 14, "bold"), bg="#2b2b2b", fg="#d8a4ff", relief="flat", borderwidth=0)
        self.close_button.pack(side='right', padx=10)
        
        # Bind mouse events for dragging
        self.title_bar.bind("<Button-1>", self.on_drag_start)
        self.title_bar.bind("<B1-Motion>", self.on_drag_motion)
        
        # Status Label
        self.status_label = tk.Label(root, text="Status: Idle", font=("Arial", 12), fg="#d8a4ff", bg="#1c1c1c")
        self.status_label.pack(pady=5)
        
        # Action Buttons
        self.inject_button = tk.Button(root, text="Inject Script", command=self.inject_script, font=("Arial", 12), bg="#6a0dad", fg="white", relief="raised", borderwidth=2)
        self.inject_button.pack(pady=10, padx=10, fill='x')
        
        self.disconnect_button = tk.Button(root, text="Disconnect", command=self.disconnect, font=("Arial", 12), bg="#6a0dad", fg="white", relief="raised", borderwidth=2)
        self.disconnect_button.pack(pady=10, padx=10, fill='x')
        

              # Title Input Field Above Console
        self.title_input_label = tk.Label(root, text="Script:", font=("Arial", 12), fg="#d8a4ff", bg="#1c1c1c")
        self.title_input_label.pack(pady=5, padx=10, anchor='w')
        
        self.title_input = tk.Entry(root, font=("Arial", 12), bg="#333333", fg="#d8a4ff", insertbackground='white')
        self.title_input.pack(pady=5, padx=10, fill='x')
        self.title_input.insert(0, "Insert Title")  # Default text

        # Console-like Log Area
        self.log_area = scrolledtext.ScrolledText(root, height=10, width=70, font=("Consolas", 12), bg="#000000", fg="#d8a4ff", borderwidth=2, relief="flat")
        self.log_area.pack(pady=10, padx=10, fill='both', expand=True)
        
        # Initial console output
        self.log_area.insert(tk.END, 'print "Hello World!"\n')
        self.log_area.see(tk.END)  # Scroll to the end of the text

    def on_drag_start(self, event):
        # Only start dragging if the click is within the title bar area
        if event.y <= 30:  # Height of the title bar
            self.drag_start_x = event.x
            self.drag_start_y = event.y

    def on_drag_motion(self, event):
        # Allow dragging only if the initial click was within the title bar area
        if self.drag_start_x and self.drag_start_y:
            dx = event.x - self.drag_start_x
            dy = event.y - self.drag_start_y
            new_x = self.root.winfo_x() + dx
            new_y = self.root.winfo_y() + dy
            self.root.geometry(f'+{new_x}+{new_y}')

    def close_app(self):
        self.root.destroy()

    def inject_script(self):
        script = self.script_entry.get()
        self.script_entry.delete(0, tk.END)  # Clear the entry field
        self.log_area.insert(tk.END, f"Injecting script: {script}\n")
        self.log_area.see(tk.END)  # Scroll to the end of the text

    def disconnect(self):
        self.log_area.insert(tk.END, "Disconnecting...\n")
        self.root.after(2000, lambda: self.log_area.insert(tk.END, "Disconnected successfully.\n"))

if __name__ == "__main__":
    root = tk.Tk()
    app = FakeRobloxInjector(root)
    root.mainloop()
